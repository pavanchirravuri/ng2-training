import {Component} from '@angular/core';

@Component({
    selector:'random-quote',
    template:`<style>.quote {
        background-color: #f00;
    }</style><div>
            <h2>Random Quote</h2>
            <p class="quote">{{quote.line}} - {{quote.author}}</p>
    </div>`,
    styles: [
        `.quote {
            background-color: #ffff00;
        }`
    ]
})

export class RandomQuoteComponent {  
    quotes: Object[] = [{
        "line": "Where there is a will there is a way..!!",
        "author": "Pavan Kumar Chirravuri"
    },{
        "line": "What you think you become..!!",
        "author": "Pavan Kumar "
    }]

    randomIndex: number = Math.floor(Math.random() * this.quotes.length);
    quote = this.quotes[this.randomIndex];

    constructor() {
        
    }
}