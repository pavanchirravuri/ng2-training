import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';



import { AppComponent } from './app.component';
import { RandomQuoteComponent } from './randomquote.component';
import {CounterComponent} from './counter.component';
import {TempConvertPipe} from './TempConvert.pipe';
import {MyFirstDirective} from './demo.directive';
import {RoundBorderComponent} from './roundborder.component';
import { HttpModule } from '@angular/http';
import {PostsService} from './posts.service';

//import {PeopleData} from './peopleData.service';


@NgModule({
  declarations: [
    AppComponent, 
    RandomQuoteComponent,
    CounterComponent,
    TempConvertPipe,
    MyFirstDirective,
    RoundBorderComponent
  ],
  imports: [
    BrowserModule, 
    FormsModule,
    HttpModule
  ],
  providers: [PostsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
