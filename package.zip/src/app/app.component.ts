import { Component, OnInit } from '@angular/core';
//import {PeopleData} from './peopleData.service';
import {Posts} from './posts.model';
import {PostsService} from './posts.service';

@Component({
  selector: 'app-root',
  template: `<div>
    <h1>{{title | titlecase}}</h1>
    <random-quote></random-quote>
    <img [src] = "imageUrl" [width]= "imgWidth" [height]="imgHeight" />
    <button (click) = "changeTitle()" >Change title</button>'
    <input type="text" [(ngModel)] = 'title' name="txttitle" /><br />

    <CounterComponent [counter] = "counterValue" (counterChanged) = "handleEvent($event)">
    </CounterComponent> 
    <h3>Pipes</h3>
    {{1234 | currency: 'USD': true}} <br />
    {{today | date: 'medium'}}<br />
    {{today | date: 'shortDate'}}<br />
    {{today | date: 'longDate'}}<br />
    {{today | date: 'EEEE, MMMM d, yyyy' | uppercase}}
    <h3>Custom Pipes</h3>
    {{37 | tempConvert}}

    <h3>Directive</h3>
    <form>
      First Name: <input type="text" name="txtName" myFirstDirective/><br />
      Last Name: <input type="text" name="txtLName" myFirstDirective/>
    </form>

    <div *ngIf="comments.length>0; else nocomments">
      <p>Comments</p>
    </div>

    <ng-template #nocomments>
      <p>No Comments yet!</p>
    </ng-template>

    <button (click) = "changeComments()" >Change Comments</button>'

    <hr />

    <select [(ngModel)] = "country">
      <option value="IN">India</option>
      <option value="UK">United Kingdom</option>
      <option value="US">USA</option>
    </select>
    <div [ngSwitch] = "country">
      <h3 *ngSwitchCase="'IN'">Indian Rupee</h3>
      <h3 *ngSwitchCase="'UK'">Pounds</h3>
      <h3 *ngSwitchCase="'US'">Dollars</h3>
    </div>
  </div>
  <br />
  <round-border>
    Hello World..!!!
  </round-border>

  <ul>
    <li *ngFor = "let person of objGoodPeople">
      {{person.name}} - {{person.yearborn}}
    </li>
  </ul> <br /> <hr />
  <h3>Http</h3>
  <ul>
  <li *ngFor = "let post of objPosts">
    {{post.title}}
  </li>
</ul> 

  `,
 // providers: [PeopleData],
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  comments: string[] = [];
  title = 'my app';
  imageUrl: string = "../assets/virat.jpg";
  imgWidth: number = 200;
  imgHeight: number = 200;
  counterValue: number = 5;
  today = new Date();
 
  handleEvent(arg:Event) {
    console.log("the counter value is "+ arg);
  }

  changeTitle() {
    this.title = "Virat Kohli";
  }

  changeComments() {
    this.comments.push('Hello');
  }

  //objGoodPeople: Object;
  objPosts: Posts;
  constructor(private postsService: PostsService) {
    postsService.getPosts()
    .subscribe((resp) => this.objPosts = resp,
      (error) => console.log(error))

  }

  // getGoodPeople(): void {
  //   this.objGoodPeople = this.people.getAllGoodPeople();
  // }

  // ngOnInit() {
  //   this.getGoodPeople();
  // }

}
